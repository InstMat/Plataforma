# Plataforma Portable de Pruebas

Esta carpeta contiene una version portable de la plataforma para crear y probar modulos/lecciones localmente, sin modificar la estructura del proyecto principal.

## Iniciar

```bash
cd plataform-portable
bash scripts/start-test-platform.sh
```

## Detener

```bash
cd plataform-portable
bash scripts/stop-test-platform.sh
```

## Generar ZIP descargable

```bash
cd plataform-portable
bash scripts/build-package.sh
```

El ZIP se genera en `plataform-portable/dist/`.

## Estructura para nuevos modulos y lecciones

Mantener exactamente este patron:

- `data/<FACULTAD>/<MODULO>/lecciones.json`
- `data/<FACULTAD>/<MODULO>/<UnidadSinEspacios>/<archivo>.html`

Ejemplo:

- `data/Ingenieria/NuevoModulo/lecciones.json`
- `data/Ingenieria/NuevoModulo/UnidadI/clase101.html`
- `data/Ingenieria/NuevoModulo/UnidadII/clase201.html`

Despues, registrar el modulo en `data/carreras.json` para que aparezca en la portada.
