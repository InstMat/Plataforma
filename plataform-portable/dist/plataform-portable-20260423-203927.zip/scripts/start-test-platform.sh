#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNTIME_DIR="$ROOT_DIR/.test-runtime"
PID_FILE="$RUNTIME_DIR/server.pid"
PORT_FILE="$RUNTIME_DIR/server.port"
LOG_FILE="$RUNTIME_DIR/server.log"

mkdir -p "$RUNTIME_DIR"

find_free_port() {
  python3 - <<'PY'
import socket
s = socket.socket()
s.bind(("127.0.0.1", 0))
print(s.getsockname()[1])
s.close()
PY
}

open_browser() {
  local url="$1"

  if [[ -n "${BROWSER:-}" ]]; then
    "$BROWSER" "$url" >/dev/null 2>&1 && return 0
  fi

  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$url" >/dev/null 2>&1 && return 0
  elif command -v open >/dev/null 2>&1; then
    open "$url" >/dev/null 2>&1 && return 0
  elif command -v powershell.exe >/dev/null 2>&1; then
    powershell.exe -NoProfile -Command "Start-Process '$url'" >/dev/null 2>&1 && return 0
  fi

  return 1
}

if [[ -f "$PID_FILE" ]]; then
  EXISTING_PID="$(cat "$PID_FILE")"
  if kill -0 "$EXISTING_PID" >/dev/null 2>&1; then
    EXISTING_PORT="$(cat "$PORT_FILE" 2>/dev/null || true)"
    EXISTING_PORT="${EXISTING_PORT:-8000}"
    URL="http://127.0.0.1:${EXISTING_PORT}/index.html"
    echo "La plataforma portable ya esta en ejecucion: $URL"
    open_browser "$URL" || true
    exit 0
  else
    rm -f "$PID_FILE" "$PORT_FILE"
  fi
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "Error: python3 no esta disponible en este equipo." >&2
  exit 1
fi

PORT="${PORT:-$(find_free_port)}"

nohup python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$ROOT_DIR" >"$LOG_FILE" 2>&1 &
SERVER_PID=$!

echo "$SERVER_PID" > "$PID_FILE"
echo "$PORT" > "$PORT_FILE"

URL="http://127.0.0.1:${PORT}/index.html"
echo "Plataforma portable iniciada en: $URL"
echo "Para detener: bash scripts/stop-test-platform.sh"

open_browser "$URL" || echo "No se pudo abrir el navegador automaticamente. Abre: $URL"
